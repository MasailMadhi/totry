-- TryOutHub Sample Data
-- This SQL file contains sample questions and packs for testing

-- Note: This is a reference file. Data is inserted via PHP in class-activator.php
-- You can use this as a template if you want to manually insert additional sample data

-- Sample Questions (20 questions across categories)
-- Categories: PK (5), PU (4), PPU (3), PBM (3), PM (3), LIT_BahasaID (2)

-- Sample Packs (7 packs)
-- 1 Full UTBK pack (free, 180 minutes, all questions)
-- 6 Category-specific packs (mix of free and premium)

-- To manually insert data, use the WordPress admin interface or run the activation hook
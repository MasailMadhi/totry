/**
 * TryOutHub Admin JavaScript
 */

(function($) {
    'use strict';

    // Nothing specific for now, but can be extended

})(jQuery);